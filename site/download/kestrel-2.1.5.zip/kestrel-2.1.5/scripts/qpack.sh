#!/bin/sh
DIST_HOME="$(dirname $0)/.."
java -server -classpath ${DIST_HOME}/libs/netty-3.2.6.Final.jar:${DIST_HOME}/libs/ostrich-4.10.0.jar:${DIST_HOME}/libs/scala-compiler-2.8.1.jar:${DIST_HOME}/libs/util-core-1.12.4.jar:${DIST_HOME}/libs/util-logging-1.12.4.jar:${DIST_HOME}/libs/json_2.8.1-2.1.6.jar:${DIST_HOME}/libs/naggati-2.1.1.jar:${DIST_HOME}/libs/scala-library-2.8.1.jar:${DIST_HOME}/libs/util-eval-1.12.4.jar:${DIST_HOME}/kestrel-2.1.5.jar net.lag.kestrel.tools.QPacker "$@"
