#!/bin/bash
echo "Starting kestrel in development mode..."
java -server -Xmx1024m -Dstage=development -jar ./dist/kestrel/kestrel_2.9.1-2.2.0.jar

